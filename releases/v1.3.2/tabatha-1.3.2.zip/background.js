// Tabatha background service worker (ES module).
// Responsibilities:
//   1. Track tab usage order (MRU) and screenshots  -> lib/store.js, lib/capture.js
//   2. Open the switcher when the shortcut is pressed -> openSwitcher()
//   3. Put focus back where it belongs when the switcher closes
//
// Trust: messages can come from the content script on any page (untrusted
// page context, possibly a compromised renderer) or from our own switcher
// page. Every message is checked for sender and shape; content scripts can
// only ask "open the switcher", nothing else.
//
// Everything here must be safe to run more than once: the worker can be
// suspended and restarted at any moment, and install/reload re-runs setup.

import { MSG, FRAME_MSG, LIMITS, SWITCHER_PAGE, WINDOW_STATES, CLOSE_REASONS } from './lib/constants.js';
import {
  touchMru, removeFromMru, replaceInMru, seedMru, getPreview, cleanupPreviews, markBoot,
  markDiscarded, moveDiscarded, ensureBoot,
  rememberTab, rememberTabs, forgetTabMeta, logClosedTab, cleanupClosedLog,
  setOverlayTab, clearOverlayTab, createLaunch, getOnboard, updateOnboard,
} from './lib/store.js';
import { syncGroups, hasGroupsApi } from './lib/groups.js';
import { scheduleCapture, cancelCapture, captureWindow } from './lib/capture.js';
import { isOwnUrl } from './lib/ext.js';

// With use_dynamic_url this is a per-session random origin, so pages can't
// probe for the extension's permanent id.
const SWITCHER_URL = chrome.runtime.getURL(SWITCHER_PAGE);
// The origin extension frames actually run in (the real id). Used as the
// postMessage target so the launch token can only ever reach our own frame.
const EXT_REAL_ORIGIN = `chrome-extension://${chrome.runtime.id}`;
const INJECTABLE = /^(https?|file):/;

// First worker start of a browser session: remember when it began (see maybeCleanup in store.js).
ensureBoot().catch(() => {});

// ------------------------------------------------------------- saved tab groups
// Events are batched: closing a window fires dozens, and by the time the batch
// settles the group is gone, so its saved copy keeps the tabs it had (see lib/groups.js).
// Only runs once the user has switched on the optional tabGroups permission.
let groupTimer = null;
function groupsChanged() {
  if (!hasGroupsApi()) return;
  clearTimeout(groupTimer);
  groupTimer = setTimeout(() => syncGroups().catch(() => {}), LIMITS.GROUP_SYNC_MS);
}
let groupListeners = false;
function listenToGroups() {
  if (groupListeners || !hasGroupsApi()) return;
  groupListeners = true;
  for (const ev of ['onCreated', 'onUpdated', 'onRemoved', 'onMoved']) chrome.tabGroups[ev].addListener(groupsChanged);
}
listenToGroups(); // top level, so a worker woken by a group event is already listening
chrome.permissions.onAdded.addListener((p) => {
  if (p.permissions && p.permissions.includes('tabGroups')) { listenToGroups(); syncGroups().catch(() => {}); }
});

// ---------------------------------------------------------------- tab events
chrome.tabs.onActivated.addListener(async ({ tabId, windowId }) => {
  clearOverlayTab();
  let tab;
  try { tab = await chrome.tabs.get(tabId); } catch { return; }
  if (isOwnUrl(tab.url) || isOwnUrl(tab.pendingUrl)) return;
  touchMru(tabId);
  scheduleCapture(windowId);
});

chrome.tabs.onCreated.addListener((tab) => { rememberTab(tab).catch(() => {}); });

chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.url || info.title || info.favIconUrl) rememberTab(tab).catch(() => {});
  // Chrome unloaded (or reloaded) this tab while we were running: that's a real "Sleeping" tab.
  if (typeof info.discarded === 'boolean') markDiscarded(tabId, info.discarded).catch(() => {});
  if (info.status === 'complete' && tab.active) {
    scheduleCapture(tab.windowId, 450);
    offerFlyout(tab);
  }
  if (info.groupId !== undefined || (tab.groupId >= 0 && (info.url || info.title))) groupsChanged();
});
chrome.tabs.onAttached.addListener(groupsChanged);
chrome.tabs.onDetached.addListener(groupsChanged);
chrome.tabs.onMoved.addListener(groupsChanged);

// Previews are keyed by URL, so a closed or replaced tab keeps its preview
// (it's what "Recently closed" shows); old ones expire in cleanupPreviews().
// Every closed tab goes into our own 7-day log, including tabs that close with
// their window (isWindowClosing): the switcher drops those from the list when
// Chrome still holds the whole window as one "Window" card.
chrome.tabs.onRemoved.addListener((tabId) => {
  removeFromMru(tabId);
  markDiscarded(tabId, false).catch(() => {});
  logClosedTab(tabId).catch(() => {});
  groupsChanged();
});

chrome.tabs.onReplaced.addListener((addedId, removedId) => {
  replaceInMru(removedId, addedId);
  forgetTabMeta(removedId).catch(() => {});
  moveDiscarded(removedId, addedId).catch(() => {});
  chrome.tabs.get(addedId).then((t) => rememberTab(t)).catch(() => {});
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;
  try {
    const [tab] = await chrome.tabs.query({ active: true, windowId });
    if (tab && !isOwnUrl(tab.url)) {
      touchMru(tab.id);
      scheduleCapture(windowId);
    }
  } catch {}
});

// ------------------------------------------------------------- setup (idempotent)
// If Chrome left the shortcut unassigned (another extension or app owns it, or a policy
// blocks it), say so in the worker console instead of failing silently.
async function checkShortcut() {
  try {
    const cmds = await chrome.commands.getAll();
    const main = cmds.find((c) => c.name === 'open-switcher');
    if (!main || !main.shortcut) console.warn('[Tabatha] The Alt+Q shortcut is not assigned. Set it at chrome://extensions/shortcuts (the in-page Alt+Q fallback still works on web pages).');
  } catch {}
}

async function setup({ fresh = false } = {}) {
  checkShortcut();
  // After an install/update every tab already exists, so it's safe to expire old previews now.
  // At browser start Chrome may still be restoring tabs (their previews must count as "in use"),
  // so there the cleanup is left to the save path, which waits a minute (maybeCleanup in store.js).
  if (fresh) cleanupPreviews().catch(() => {});
  cleanupClosedLog().catch(() => {}); // ...and the 7-day closed-tab log
  chrome.tabs.query({ windowType: 'normal' }).then(rememberTabs).catch(() => {}); // what each open tab is, for the log
  groupsChanged(); // saved tab groups (if switched on)
  const active = await chrome.tabs.query({ active: true, windowType: 'normal' });
  await seedMru(active.map((t) => t.id));
  const [focused] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (focused) scheduleCapture(focused.windowId, 200);
}

chrome.runtime.onStartup.addListener(async () => {
  await markBoot().catch(() => {}); // start of a browser session: tab ids and the "slept" list are new
  await setup();
});
chrome.runtime.onInstalled.addListener(async (details) => {
  await setup({ fresh: true });
  if (details.reason === 'install') {
    await updateOnboard({ at: Date.now(), flyout: false, tour: false }).catch(() => {});
    const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true }).catch(() => []);
    if (t) offerFlyout(t);
  }
  // Tabs that were open before install/reload don't have the content script
  // yet. hotkey.js guards itself, so injecting twice is harmless.
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*', 'file://*/*'] });
  await Promise.allSettled(tabs.map((t) =>
    chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ['hotkey.js'] })));
});

// ------------------------------------------------------------ opening the switcher
let opening = null;   // { t, extra } while a switcher is loading (dedupes rapid presses)
let watchdog = null;  // { token, timer } for an overlay that hasn't reported READY yet
let lastTrigger = 0;

function trigger(dir, tab) {
  // Both Chrome's shortcut and the in-page listener may see the same press;
  // this also rate-limits a misbehaving sender.
  if (Date.now() - lastTrigger < 120) return;
  lastTrigger = Date.now();
  openSwitcher(dir, tab).catch((e) => console.warn('[Tabatha] could not open the switcher:', e && e.message));
}

async function openSwitcher(dir, fromTab) {
  // 1. Already open anywhere? Just move its selection.
  try {
    const r = await chrome.runtime.sendMessage({ type: MSG.CYCLE, dir });
    if (r && r.ok) return;
  } catch { /* no switcher open */ }

  // 2. Still loading from a press a moment ago? Queue the move for it.
  if (opening && Date.now() - opening.t < LIMITS.OPENING_LOCK_MS) {
    opening.extra += dir;
    return;
  }
  opening = { t: Date.now(), extra: 0 };

  let tab = fromTab;
  if (!tab || !tab.active) [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab || tab.incognito) { opening = null; return; }

  let win = {};
  try { win = await chrome.windows.get(tab.windowId); } catch {}

  // 3. Refresh the current tab's screenshot before anything covers it.
  cancelCapture(tab.windowId);
  const prev = await getPreview(tab.url);
  if (!prev || Date.now() - prev.t > 1500) {
    await Promise.race([
      captureWindow(tab.windowId, { force: true }).catch(() => {}),
      new Promise((r) => setTimeout(r, 900)),
    ]);
  }

  const ctx = {
    src: tab.id, win: tab.windowId, dir,
    state: WINDOW_STATES.includes(win.state) ? win.state : 'normal',
  };

  // 4. Show it inside the page; fall back to a popup window where extensions
  //    can't inject (chrome://, New Tab, Web Store) or the overlay fails.
  if (INJECTABLE.test(tab.url || '')) {
    try {
      const token = await createLaunch({ ...ctx, mode: 'overlay' });
      await setOverlayTab(tab.id);
      armWatchdog(token, tab.id, win, ctx); // before injecting: READY can arrive very quickly
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: injectOverlay,
        args: [SWITCHER_URL, token, EXT_REAL_ORIGIN, FRAME_MSG],
      });
      return;
    } catch {
      disarmWatchdog();
      await clearOverlayTab();
    }
  }
  await openPopupWindow(win, await createLaunch({ ...ctx, mode: 'window' }));
}

// Some pages block the overlay's scripts (e.g. a "Content-Security-Policy:
// sandbox" header) or never render it. If the switcher hasn't said READY in
// time, remove the overlay and use the popup window instead.
function armWatchdog(token, tabId, win, ctx) {
  disarmWatchdog();
  watchdog = {
    token,
    timer: setTimeout(async () => {
      if (!watchdog || watchdog.token !== token) return;
      watchdog = null;
      await chrome.scripting.executeScript({ target: { tabId }, func: removeOverlay }).catch(() => {});
      await clearOverlayTab();
      opening = null;
      await openPopupWindow(win, await createLaunch({ ...ctx, mode: 'window' })).catch(() => {});
    }, LIMITS.OVERLAY_WATCHDOG_MS),
  };
}

function disarmWatchdog() {
  if (watchdog) clearTimeout(watchdog.timer);
  watchdog = null;
}

async function openPopupWindow(win, token) {
  const url = SWITCHER_URL + '?t=' + token;
  const W = win.width || 1280, H = win.height || 800;
  const w = Math.round(Math.min(1180, W - 80));
  const h = Math.round(Math.min(780, H - 80));
  try {
    await chrome.windows.create({
      url, type: 'popup', focused: true, width: w, height: h,
      left: Math.round((win.left || 0) + (W - w) / 2),
      top: Math.round((win.top || 0) + (H - h) / 2),
    });
  } catch {
    // Bounds rejected (window partly off-screen, odd multi-monitor layout):
    // let Chrome place it.
    await chrome.windows.create({ url, type: 'popup', focused: true });
  }
}

// Runs *inside the web page* (content-script isolated world). Page scripts
// can't see these variables, but they CAN see and restyle the iframe element,
// so: the iframe URL carries nothing sensitive - the one-time launch token is handed
// to the frame with postMessage, addressed to the extension's own origin (if
// the page swaps the frame for something else, the token isn't delivered);
// and the switcher refuses clicks while it's hidden or covered.
// Re-running it replaces the previous overlay cleanly.
function injectOverlay(src, token, extOrigin, FRAME) {
  const prev = window.__tabathaOverlay;
  if (prev) prev.cleanup();

  const prevFocus = document.activeElement;
  // The blur sits on a separate element *behind* the iframe. Putting it on
  // the iframe itself would make Chrome report the frame as "not visible"
  // (a visual effect on an ancestor), which disables the switcher's
  // clickjacking guard.
  const base = [
    'all:initial', 'display:block', 'position:fixed', 'inset:0', 'width:100vw', 'height:100vh',
    'border:0', 'margin:0', 'padding:0', 'z-index:2147483647', 'opacity:0', 'pointer-events:none',
    'transition:opacity .12s ease',
  ];
  const shade = document.createElement('div');
  shade.style.cssText = [...base,
    'backdrop-filter:blur(18px) brightness(.45) saturate(1.2)',
    '-webkit-backdrop-filter:blur(18px) brightness(.45) saturate(1.2)',
  ].join(';');
  const frame = document.createElement('iframe');
  frame.src = src;
  frame.setAttribute('allowtransparency', 'true');
  frame.setAttribute('aria-label', 'Tabatha tab switcher');
  // Invisible and click-through until the switcher reports it has rendered,
  // so a page that blocks it is never left covered by an empty frame.
  frame.style.cssText = [...base, 'background:transparent', 'color-scheme:normal'].join(';');

  const onMsg = (e) => {
    if (e.source !== frame.contentWindow || !e.data || typeof e.data.tabatha !== 'string') return;
    if (e.data.tabatha === FRAME.READY) {
      shade.style.opacity = '1';
      frame.style.opacity = '1';
      frame.style.pointerEvents = 'auto';
    } else if (e.data.tabatha === FRAME.CLOSE) {
      cleanup();
    }
  };
  const onVis = () => { if (document.hidden) cleanup(); };
  function cleanup() {
    window.removeEventListener('message', onMsg, true);
    document.removeEventListener('visibilitychange', onVis, true);
    frame.remove();
    shade.remove();
    if (window.__tabathaOverlay && window.__tabathaOverlay.frame === frame) delete window.__tabathaOverlay;
    try { if (prevFocus && prevFocus.focus) prevFocus.focus({ preventScroll: true }); } catch {}
  }

  window.addEventListener('message', onMsg, true);
  document.addEventListener('visibilitychange', onVis, true);
  frame.addEventListener('load', () => {
    frame.focus();
    try { frame.contentWindow.postMessage({ tabatha: FRAME.LAUNCH, token }, extOrigin); } catch {}
  });
  (document.body || document.documentElement).append(shade, frame);
  frame.focus();
  window.__tabathaOverlay = { frame, cleanup };
}

function removeOverlay() {
  if (window.__tabathaOverlay) window.__tabathaOverlay.cleanup();
}

// ------------------------------------------------------------ closing the switcher
// Windows treats Alt+Esc as "send this window to the back", so pressing Esc
// while still holding Alt made Chrome look minimised. After a cancel we put
// the window back in front (and un-minimise it if needed).
async function restoreWindow(windowId, state) {
  try {
    const w = await chrome.windows.get(windowId);
    if (w.state === 'minimized') {
      await chrome.windows.update(windowId, { state: WINDOW_STATES.includes(state) ? state : 'normal' });
    }
    await chrome.windows.update(windowId, { focused: true });
  } catch {}
}

// ------------------------------------------------------------ first-run flyout
// Right after a fresh install a small card on the page says "Press Alt+Q". Pages
// extensions can't touch (the Web Store, chrome://) can't show it, so it is offered
// again on the next ordinary page the user loads, for a short while. It goes away
// when dismissed, after 20 s, or as soon as the switcher has been opened once.
async function offerFlyout(tab) {
  try {
    if (!tab || !INJECTABLE.test(tab.url || '') || tab.incognito) return;
    const o = await getOnboard();
    if (!o.at || o.flyout || o.tour || Date.now() - o.at > LIMITS.FLYOUT_WINDOW_MS) return;
    await chrome.scripting.executeScript({
      target: { tabId: tab.id }, func: injectFlyout, args: [MSG.FLYOUT_DONE, LIMITS.FLYOUT_SHOW_MS],
    });
  } catch {}
}

// Runs inside the page (isolated world). A closed shadow root keeps the page's CSS out and
// its scripts away from our nodes; text is set with textContent only.
function injectFlyout(doneType, showMs) {
  if (window.__tabathaFlyout) return;
  const mac = /mac/i.test((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '');
  const host = document.createElement('div');
  host.style.cssText = 'all:initial;position:fixed;top:16px;right:16px;z-index:2147483646';
  const root = host.attachShadow({ mode: 'closed' });
  const style = document.createElement('style');
  style.textContent = `
    .c{font:14px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;color:#1B2A4A;background:#FFF8E7;width:280px;padding:14px 16px 14px;
       border:3px solid #1B2A4A;border-radius:4px;box-shadow:4px 4px 0 #1B2A4A;animation:in .25s steps(4) both}
    @keyframes in{from{transform:translateY(-10px);opacity:0}to{transform:none;opacity:1}}
    .t{font-weight:700;font-size:15px;margin:0 22px 6px 0}.p{margin:0 0 10px}
    kbd{font:inherit;font-weight:700;background:#FFD166;border:2px solid #1B2A4A;border-radius:3px;padding:1px 7px}
    .s{font-size:12px;opacity:.75;margin:0}
    button{position:absolute;top:6px;right:8px;border:0;background:none;font-size:20px;line-height:1;cursor:pointer;color:#1B2A4A}`;
  const box = document.createElement('div'); box.className = 'c'; box.setAttribute('role', 'status');
  const t = document.createElement('p'); t.className = 't'; t.textContent = 'Tabatha is ready';
  const p = document.createElement('p'); p.className = 'p';
  const k = document.createElement('kbd'); k.textContent = mac ? 'Option+Q' : 'Alt+Q';
  p.append('Press ', k, ' to see all your tabs.');
  const s = document.createElement('p'); s.className = 's'; s.textContent = 'Or click the Tabatha icon in the toolbar.';
  const x = document.createElement('button'); x.type = 'button'; x.setAttribute('aria-label', 'Dismiss'); x.textContent = '\u00d7';
  box.append(t, p, s, x); root.append(style, box);
  const done = () => {
    clearTimeout(timer); host.remove(); delete window.__tabathaFlyout;
    chrome.runtime.sendMessage({ type: doneType }).catch(() => {});
  };
  x.addEventListener('click', done);
  const timer = setTimeout(() => { host.remove(); delete window.__tabathaFlyout; }, showMs); // left alone: offered again on the next page
  window.__tabathaFlyout = { host };
  (document.body || document.documentElement).append(host);
}

// --------------------------------------------------------------- entry points
// MV3 note: this worker is not persistent; Chrome stops it when idle and starts it again for
// an event. Keep every listener registered at the top level, synchronously (nothing awaited
// before it), or the event that woke the worker can be missed. If a user reports "Alt+Q
// does nothing until I click the toolbar icon": (1) is the shortcut assigned? (checkShortcut
// logs a warning, and chrome://extensions/shortcuts shows it); (2) managed browsers can
// restrict extension shortcuts by policy; (3) hotkey.js is the fallback and retries once
// (see send() there). A keep-alive alarm would need the `alarms` permission: last resort.
chrome.commands.onCommand.addListener((command, tab) => {
  if (command === 'open-switcher') trigger(1, tab);
  else if (command === 'open-switcher-reverse') trigger(-1, tab);
});

chrome.action.onClicked.addListener((tab) => trigger(1, tab));

const fromContentScript = (s) => !!s.tab && Number.isInteger(s.tab.id) && !isOwnUrl(s.url);
const fromSwitcher = (s) => isOwnUrl(s.url, SWITCHER_PAGE);

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (sender.id !== chrome.runtime.id || !msg || typeof msg !== 'object' || typeof msg.type !== 'string') return;
  switch (msg.type) {
    case MSG.HOTKEY:
      // The only thing a page's content script may ask for.
      if (fromContentScript(sender)) trigger(msg.dir === -1 ? -1 : 1, sender.tab);
      return;
    case MSG.READY:
      if (!fromSwitcher(sender)) return;
      disarmWatchdog();
      respond({ extra: opening ? Math.max(-20, Math.min(20, opening.extra)) : 0 });
      opening = null;
      return;
    case MSG.GROUPS:
      if (fromSwitcher(sender)) syncGroups().catch(() => {});
      return;
    case MSG.FLYOUT_DONE:
      if (fromContentScript(sender)) updateOnboard({ flyout: true }).catch(() => {});
      return;
    case MSG.CLOSED:
      if (!fromSwitcher(sender)) return;
      disarmWatchdog();
      opening = null;
      clearOverlayTab();
      if (msg.reason === 'cancel' && Number.isInteger(msg.win)) {
        const state = WINDOW_STATES.includes(msg.state) ? msg.state : 'normal';
        restoreWindow(msg.win, state);
        setTimeout(() => restoreWindow(msg.win, state), 250); // after the OS acts on Alt+Esc
      } else if (!CLOSE_REASONS.includes(msg.reason)) {
        console.warn('[Tabatha] unexpected close reason');
      }
      return;
  }
});
